# Contributing to oxDNA

* Copy (or even better, link) the `pre-commit` script to the `.git/hooks` directory of your local copy and make sure that it is executable. The script checks that the `RELEASE` macro defined in `src/defs.h` coincides with the current git tag.
