---
name: Documentation issue
about: Suggest improvements or additions to documentation
title: "[DOCUMENTATION] XXX"
labels: documentation
assignees: ''

---

**What is the documentation missing?**
A clear and concise description of what is missing/what can be improved in the documentation.

**Additional context**
Add any other context about the issue here.
