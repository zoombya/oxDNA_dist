#include "DNAInteraction_nomesh.h"


DNAInteraction_nomesh::DNAInteraction_nomesh() : DNAInteraction() {

}


DNAInteraction_nomesh::~DNAInteraction_nomesh() {

}
