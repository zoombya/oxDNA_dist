rm -f align* angle* *.json *.pyidx *.png *.npy *.mp4 centroid* cluster* forces.txt gen_pairs.txt db* test_pairs.txt mean* min.dat sub*
